#!/bin/bash
# We use double quotes around variables to treat their contents as a single argument.
# Use cmp to compare files.

if [ $# -eq 2 ]; then
    original=$1
    restore=$2
    whitelist="whitelist.txt"

    if [ ! -d "$original" ]; then
        echo "Directory $original does not exist."
        exit 1
    fi

    mkdir -p "$restore"

    scan_files() {
        shopt -s nullglob dotglob
        files=("$original"/*)

        for f in "${files[@]}"; do
            [ -f "$f" ] || continue
            hash=$(sha256sum "$f" | cut -d ' ' -f1)
            extension="${f##*.}"
            result="$hash$extension"

            if grep -Fqx "$result" "$whitelist" 2>/dev/null; then
                continue
            fi

            virus=$(grep -Eci "virus|trojan|malware|worm|ransomware" "$f")
            if [ "$extension" = "exe" ] || [ "$extension" = "bat" ] || [ "$extension" = "vbs" ] || [ "$extension" = "scr" ] || [ "$extension" = "ps1" ] || [ "$virus" -gt 0 ]; then
                echo "$f is malicious and it is DELETED"
                cp "$f" "$restore"
                rm "$f"
            fi
        done
    }

    if [ ! -f directory-info.last ]; then
        scan_files
        ls -l "$original" > directory-info.last
    else
        ls -l "$original" > directory-info.new
        if ! cmp -s directory-info.last directory-info.new; then
            scan_files
            ls -l "$original" > directory-info.last
        fi
    fi
else
    echo "Usage: $0 dir malicious_dir"
fi
